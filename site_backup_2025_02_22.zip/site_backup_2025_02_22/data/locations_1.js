var json_locations_1 = {
  type: "FeatureCollection",
  name: "locations_1",
  crs: { type: "name", properties: { name: "urn:ogc:def:crs:OGC:1.3:CRS84" } },
  features: [
    {
      type: "Feature",
      properties: {
        City: "Hercules",
        Date: "(Extended Residency)",
        Details: "(Extended Residency)",
      },
      geometry: {
        type: "Point",
        coordinates: [-122.23564035268339, 37.945702007327725],
      },
    },
    {
      type: "Feature",
      properties: {
        City: "Clear Lake",
        Date: "November 19th, 2009",
        Details: "Campsite Bathroom",
      },
      geometry: { type: "Point", coordinates: [-121.997191, 44.366983] },
    },
    {
      type: "Feature",
      properties: {
        City: "Panguitch",
        Date: "May, 2013",
        Details: "KOA Campground",
      },
      geometry: { type: "Point", coordinates: [-112.434802, 37.814668] },
    },
    {
      type: "Feature",
      properties: {
        City: "Missoula",
        Date: "July 16th, 2012",
        Details: "Bel Aire Motel",
      },
      geometry: { type: "Point", coordinates: [-114.324987, 48.206779] },
    },
    {
      type: "Feature",
      properties: {
        City: "Minneapolis",
        Date: "(Extended Residency)",
        Details: "(Extended Residency)",
      },
      geometry: { type: "Point", coordinates: [-93.223402, 44.971553] },
    },
    {
      type: "Feature",
      properties: {
        City: "Meeker",
        Date: "October 20th, 2011",
        Details: "Meeker Hotel and Cafe",
      },
      geometry: { type: "Point", coordinates: [-107.910142, 40.037498] },
    },
    {
      type: "Feature",
      properties: {
        City: "Riverton",
        Date: "July 12th, 2012",
        Details: "Tomahawk Motor Lodge",
      },
      geometry: { type: "Point", coordinates: [-108.419932, 43.04516] },
    },
    {
      type: "Feature",
      properties: {
        City: "Omaha",
        Date: "September 14th, 2011",
        Details: "Environmental Research Trip",
      },
      geometry: { type: "Point", coordinates: [-95.994166, 41.237683] },
    },
    {
      type: "Feature",
      properties: {
        City: "Bismarck",
        Date: "September 3rd, 2012",
        Details: "Environmental Research Trip",
      },
      geometry: { type: "Point", coordinates: [-100.761898, 46.81373] },
    },
    {
      type: "Feature",
      properties: {
        City: "Rapid City",
        Date: "December 28th, 2010",
        Details: "Environmental Research Trip",
      },
      geometry: { type: "Point", coordinates: [-103.201777, 44.09552] },
    },
    {
      type: "Feature",
      properties: {
        City: "Council Bluffs",
        Date: "September 13th, 2011",
        Details: "Settle Inn & Suites",
      },
      geometry: { type: "Point", coordinates: [-95.848519, 41.200123] },
    },
    {
      type: "Feature",
      properties: {
        City: "St. Joseph",
        Date: "September 15th, 2011",
        Details: "The Ramada, St. Joseph",
      },
      geometry: { type: "Point", coordinates: [-94.839152, 39.767129] },
    },
    {
      type: "Feature",
      properties: {
        City: "New Orleans",
        Date: "November 18th, 2014",
        Details: "LSU Building - 7th floor, mens bathroom during info session",
      },
      geometry: { type: "Point", coordinates: [-90.051044, 30.004603] },
    },
    {
      type: "Feature",
      properties: {
        City: "Tupelo",
        Date: "November 11th, 2014",
        Details: "Love's in Tupelo during bus trip",
      },
      geometry: { type: "Point", coordinates: [-88.791769, 34.316336] },
    },
    {
      type: "Feature",
      properties: {
        City: "Birmingham",
        Date: "April 16th, 2012",
        Details: "Environmental Research Trip",
      },
      geometry: { type: "Point", coordinates: [-86.802525, 33.51863] },
    },
    {
      type: "Feature",
      properties: {
        City: "Lillington",
        Date: "November 9th, 2014",
        Details: "Johnny's Bathroom",
      },
      geometry: { type: "Point", coordinates: [-78.817065, 35.399825] },
    },
    {
      type: "Feature",
      properties: {
        City: "Memphis",
        Date: "November 12th, 2014",
        Details: "Port-a-potty outside of the Liberty Dome",
      },
      geometry: { type: "Point", coordinates: [-89.924176, 35.103707] },
    },
    {
      type: "Feature",
      properties: {
        City: "Houghton",
        Date: "September 20th, 2011",
        Details: "Holiday Inn Express",
      },
      geometry: { type: "Point", coordinates: [-88.572485, 47.116613] },
    },
    {
      type: "Feature",
      properties: {
        City: "Norfolk",
        Date: "November 5th, 2014",
        Details: "Taylor's Bathroom",
      },
      geometry: { type: "Point", coordinates: [-76.255545, 36.914206] },
    },
    {
      type: "Feature",
      properties: {
        City: "Troy",
        Date: "(Extended Residency)",
        Details: "(Extended Residency)",
      },
      geometry: { type: "Point", coordinates: [-73.680276, 42.730653] },
    },
    {
      type: "Feature",
      properties: {
        City: "Autin",
        Date: "(Extended Residency)",
        Details: "(Extended Residency)",
      },
      geometry: { type: "Point", coordinates: [-97.739636, 30.317803] },
    },
    {
      type: "Feature",
      properties: {
        City: "Arkadelphia",
        Date: "November 30th, 2014",
        Details:
          "Megabus Trip from Memphis, TN to Dallas, TX 9 miles east of Arkadelphia mile 87/88",
      },
      geometry: { type: "Point", coordinates: [-93.055707, 34.170702] },
    },
    {
      type: "Feature",
      properties: {
        City: "Las Vegas Airport",
        Date: "March 26th, 2015",
        Details: "Layover in Las Vegas from SFO to MSP",
      },
      geometry: { type: "Point", coordinates: [-115.254489, 36.19883] },
    },
    {
      type: "Feature",
      properties: {
        City: "Greenwood",
        Date: "April 24th, 2015",
        Details:
          "Megabus Trip from Chicago to Nashville ~2:35 pm southbound on I65 going past Greenwood",
      },
      geometry: { type: "Point", coordinates: [-86.077601, 39.607106] },
    },
    {
      type: "Feature",
      properties: {
        City: "Bowling Green",
        Date: "April 24th, 2015",
        Details:
          "Megabus Trip from Chicago to Nashville ~6:25 pm southbound ~52 miles before Bowling Green",
      },
      geometry: { type: "Point", coordinates: [-86.198024, 37.037046] },
    },
    {
      type: "Feature",
      properties: {
        City: "Vancouver",
        Date: "November 25th, 2015",
        Details: "IHOP - Fisher's Landing ~11:40am",
      },
      geometry: { type: "Point", coordinates: [-122.593545, 45.634565] },
    },
    {
      type: "Feature",
      properties: {
        City: "La Crosse",
        Date: "September 12th, 2011",
        Details: "Best Western Riverfront Hotel",
      },
      geometry: { type: "Point", coordinates: [-91.243565, 43.826035] },
    },
    {
      type: "Feature",
      properties: {
        City: "Bloomington",
        Date: "September 17th, 2011",
        Details: "Double Tree",
      },
      geometry: { type: "Point", coordinates: [-88.969795, 40.481419] },
    },
    {
      type: "Feature",
      properties: {
        City: "Phoenix",
        Date: "April 18th, 2020",
        Details: "Fairfield Inn & Suites - Phoenix Midtown, ~8:12pm",
      },
      geometry: { type: "Point", coordinates: [-112.074364, 33.476048] },
    },
    {
      type: "Feature",
      properties: {
        City: "Boise",
        Date: "July 5th, 2020",
        Details: "Courtyard by Marriot, ~3:25pm",
      },
      geometry: { type: "Point", coordinates: [-116.191701, 43.608046] },
    },
    {
      type: "Feature",
      properties: {
        City: "Tilghman Island",
        Date: "October 11th, 2024",
        Details: "Knapp's Narrows Marina & Inn, ~5:00pm",
      },
      geometry: {
        type: "Point",
        coordinates: [-76.33347779526925, 38.72118374266924],
      },
    },
  ],
};
